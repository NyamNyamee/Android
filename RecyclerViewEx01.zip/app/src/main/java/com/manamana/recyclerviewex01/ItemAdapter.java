package com.manamana.recyclerviewex01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    List<String> list;

    public ItemAdapter(List<String> list) {
        this.list = list;
    }

    // 사용자가 보여줄 위젯들의 집합
    public class ViewHolder extends RecyclerView.ViewHolder{
        // 뷰 홀더에 있는 아이템을 찾아서 변수에 대입
        TextView textView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.tv);
        }
    }
    @NonNull
    @Override
    public ItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // XML을 읽어서 뷰홀더를 만들어 리턴
        Context context = parent.getContext();
        LayoutInflater inflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.recyclerview_item, parent, false);
        ItemAdapter.ViewHolder viewHolder = new ItemAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ItemAdapter.ViewHolder holder, int position) {
        // 재사용될때 호출된다. : 데이터를 변경해준다.
        holder.textView.setText(list.get(position));
    }

    @Override
    public int getItemCount() { // 데이터의 개수
        return list.size();
    }
}
